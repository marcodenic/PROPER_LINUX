#pragma once
#include <cstdint>
#include <string>
#include <string_view>
#include <span>

namespace emoji {

enum class SkinTone : std::uint8_t { Default, Light, MediumLight, Medium, MediumDark, Dark };

struct SkinToneInfo {
  SkinTone tone;
  std::string_view id;
  std::string_view displayName;
  std::string_view utf8;
};

constexpr std::uint8_t skinToneCount = 6;

std::span<const SkinToneInfo> skinTones();
SkinToneInfo skinToneInfo(SkinTone tone);
std::string applySkinTone(std::string_view emoji, SkinTone tone);

bool isUtf8EncodedEmoji(std::string_view str);

} // namespace emoji
