/**
 * Latin-script diacritic folding table, plus transliteration for scripts that need
 * more than one ASCII character per letter.
 *
 * Ported from fzf (src/algo/normalize.go), then augmented with the missing
 * upper/lower case partners (fzf omits most Latin Extended-A capitals such as
 * Ł, Ą, Ž), so folding is symmetric across case. Each accented or variant Latin
 * codepoint maps to its base ASCII character, making fuzzy matching
 * diacritic-insensitive.
 * Reference: http://www.unicode.org/Public/UCD/latest/ucd/Index.txt
 */

#pragma once
#include <algorithm>
#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <utility>

namespace fzf {

struct FoldEntry {
  char32_t cp;
  char base;
};

inline constexpr auto NORMALIZE_TABLE = [] {
  auto table = std::to_array<FoldEntry>({
      {0x00C0, 'A'},  {0x00C1, 'A'},  {0x00C2, 'A'}, {0x00C3, 'A'}, {0x00C4, 'A'}, {0x00C5, 'A'},
      {0x00C7, 'C'},  {0x00C8, 'E'},  {0x00C9, 'E'}, {0x00CA, 'E'}, {0x00CB, 'E'}, {0x00CC, 'I'},
      {0x00CD, 'I'},  {0x00CE, 'I'},  {0x00CF, 'I'}, {0x00D1, 'N'}, {0x00D2, 'O'}, {0x00D3, 'O'},
      {0x00D4, 'O'},  {0x00D5, 'O'},  {0x00D6, 'O'}, {0x00D8, 'O'}, {0x00D9, 'U'}, {0x00DA, 'U'},
      {0x00DB, 'U'},  {0x00DC, 'U'},  {0x00DD, 'Y'}, {0x00DF, 's'}, {0x00E0, 'a'}, {0x00E1, 'a'},
      {0x00E2, 'a'},  {0x00E3, 'a'},  {0x00E4, 'a'}, {0x00E5, 'a'}, {0x00E7, 'c'}, {0x00E8, 'e'},
      {0x00E9, 'e'},  {0x00EA, 'e'},  {0x00EB, 'e'}, {0x00EC, 'i'}, {0x00ED, 'i'}, {0x00EE, 'i'},
      {0x00EF, 'i'},  {0x00F1, 'n'},  {0x00F2, 'o'}, {0x00F3, 'o'}, {0x00F4, 'o'}, {0x00F5, 'o'},
      {0x00F6, 'o'},  {0x00F8, 'o'},  {0x00F9, 'u'}, {0x00FA, 'u'}, {0x00FB, 'u'}, {0x00FC, 'u'},
      {0x00FD, 'y'},  {0x00FF, 'y'},  {0x0100, 'A'}, {0x0101, 'a'}, {0x0102, 'A'}, {0x0103, 'a'},
      {0x0104, 'A'},  {0x0105, 'a'},  {0x0106, 'C'}, {0x0107, 'c'}, {0x0108, 'C'}, {0x0109, 'c'},
      {0x010A, 'C'},  {0x010B, 'c'},  {0x010C, 'C'}, {0x010D, 'c'}, {0x010E, 'D'}, {0x010F, 'd'},
      {0x0110, 'D'},  {0x0111, 'd'},  {0x0112, 'E'}, {0x0113, 'e'}, {0x0114, 'E'}, {0x0115, 'e'},
      {0x0116, 'E'},  {0x0117, 'e'},  {0x0118, 'E'}, {0x0119, 'e'}, {0x011A, 'E'}, {0x011B, 'e'},
      {0x011C, 'G'},  {0x011D, 'g'},  {0x011E, 'G'}, {0x011F, 'g'}, {0x0120, 'G'}, {0x0121, 'g'},
      {0x0122, 'G'},  {0x0123, 'g'},  {0x0124, 'H'}, {0x0125, 'h'}, {0x0126, 'H'}, {0x0127, 'h'},
      {0x0128, 'I'},  {0x0129, 'i'},  {0x012A, 'I'}, {0x012B, 'i'}, {0x012C, 'I'}, {0x012D, 'i'},
      {0x012E, 'I'},  {0x012F, 'i'},  {0x0130, 'I'}, {0x0131, 'i'}, {0x0134, 'J'}, {0x0135, 'j'},
      {0x0136, 'K'},  {0x0137, 'k'},  {0x0139, 'L'}, {0x013A, 'l'}, {0x013B, 'L'}, {0x013C, 'l'},
      {0x013D, 'L'},  {0x013E, 'l'},  {0x013F, 'L'}, {0x0140, 'l'}, {0x0141, 'L'}, {0x0142, 'l'},
      {0x0143, 'N'},  {0x0144, 'n'},  {0x0145, 'N'}, {0x0146, 'n'}, {0x0147, 'N'}, {0x0148, 'n'},
      {0x014C, 'O'},  {0x014D, 'o'},  {0x014E, 'O'}, {0x014F, 'o'}, {0x0150, 'O'}, {0x0151, 'o'},
      {0x0154, 'R'},  {0x0155, 'r'},  {0x0156, 'R'}, {0x0157, 'r'}, {0x0158, 'R'}, {0x0159, 'r'},
      {0x015A, 'S'},  {0x015B, 's'},  {0x015C, 'S'}, {0x015D, 's'}, {0x015E, 'S'}, {0x015F, 's'},
      {0x0160, 'S'},  {0x0161, 's'},  {0x0162, 'T'}, {0x0163, 't'}, {0x0164, 'T'}, {0x0165, 't'},
      {0x0166, 'T'},  {0x0167, 't'},  {0x0168, 'U'}, {0x0169, 'u'}, {0x016A, 'U'}, {0x016B, 'u'},
      {0x016C, 'U'},  {0x016D, 'u'},  {0x016E, 'U'}, {0x016F, 'u'}, {0x0170, 'U'}, {0x0171, 'u'},
      {0x0172, 'U'},  {0x0173, 'u'},  {0x0174, 'W'}, {0x0175, 'w'}, {0x0176, 'Y'}, {0x0177, 'y'},
      {0x0178, 'Y'},  {0x0179, 'Z'},  {0x017A, 'z'}, {0x017B, 'Z'}, {0x017C, 'z'}, {0x017D, 'Z'},
      {0x017E, 'z'},  {0x017F, 's'},  {0x0180, 'b'}, {0x0181, 'B'}, {0x0182, 'B'}, {0x0183, 'b'},
      {0x0186, 'O'},  {0x0187, 'C'},  {0x0188, 'c'}, {0x0189, 'D'}, {0x018A, 'D'}, {0x018B, 'D'},
      {0x018C, 'd'},  {0x018E, 'E'},  {0x0190, 'E'}, {0x0191, 'F'}, {0x0192, 'f'}, {0x0193, 'G'},
      {0x0197, 'I'},  {0x0198, 'K'},  {0x0199, 'k'}, {0x019A, 'l'}, {0x019C, 'M'}, {0x019D, 'N'},
      {0x019E, 'n'},  {0x019F, 'O'},  {0x01A0, 'O'}, {0x01A1, 'o'}, {0x01A4, 'P'}, {0x01A5, 'p'},
      {0x01A6, 'R'},  {0x01AB, 't'},  {0x01AC, 'T'}, {0x01AD, 't'}, {0x01AE, 'T'}, {0x01AF, 'U'},
      {0x01B0, 'u'},  {0x01B2, 'V'},  {0x01B3, 'Y'}, {0x01B4, 'y'}, {0x01B5, 'Z'}, {0x01B6, 'z'},
      {0x01CD, 'A'},  {0x01CE, 'a'},  {0x01CF, 'I'}, {0x01D0, 'i'}, {0x01D1, 'O'}, {0x01D2, 'o'},
      {0x01D3, 'U'},  {0x01D4, 'u'},  {0x01DD, 'e'}, {0x01E4, 'G'}, {0x01E5, 'g'}, {0x01E6, 'G'},
      {0x01E7, 'g'},  {0x01E8, 'K'},  {0x01E9, 'k'}, {0x01EA, 'O'}, {0x01EB, 'o'}, {0x01F0, 'j'},
      {0x01F4, 'G'},  {0x01F5, 'g'},  {0x01F8, 'N'}, {0x01F9, 'n'}, {0x0200, 'A'}, {0x0201, 'a'},
      {0x0202, 'A'},  {0x0203, 'a'},  {0x0204, 'E'}, {0x0205, 'e'}, {0x0206, 'E'}, {0x0207, 'e'},
      {0x0208, 'I'},  {0x0209, 'i'},  {0x020A, 'I'}, {0x020B, 'i'}, {0x020C, 'O'}, {0x020D, 'o'},
      {0x020E, 'O'},  {0x020F, 'o'},  {0x0210, 'R'}, {0x0211, 'r'}, {0x0212, 'R'}, {0x0213, 'r'},
      {0x0214, 'U'},  {0x0215, 'u'},  {0x0216, 'U'}, {0x0217, 'u'}, {0x0218, 'S'}, {0x0219, 's'},
      {0x021A, 'T'},  {0x021B, 't'},  {0x021E, 'H'}, {0x021F, 'h'}, {0x0220, 'N'}, {0x0221, 'd'},
      {0x0224, 'Z'},  {0x0225, 'z'},  {0x0226, 'A'}, {0x0227, 'a'}, {0x0228, 'E'}, {0x0229, 'e'},
      {0x022E, 'O'},  {0x022F, 'o'},  {0x0232, 'Y'}, {0x0233, 'y'}, {0x0234, 'l'}, {0x0235, 'n'},
      {0x0236, 't'},  {0x0237, 'j'},  {0x023A, 'A'}, {0x023B, 'C'}, {0x023C, 'c'}, {0x023D, 'L'},
      {0x023E, 'T'},  {0x023F, 's'},  {0x0240, 'z'}, {0x0243, 'B'}, {0x0244, 'U'}, {0x0245, 'V'},
      {0x0246, 'E'},  {0x0247, 'e'},  {0x0248, 'J'}, {0x0249, 'j'}, {0x024A, 'Q'}, {0x024B, 'q'},
      {0x024C, 'R'},  {0x024D, 'r'},  {0x024E, 'Y'}, {0x024F, 'y'}, {0x0250, 'a'}, {0x0251, 'a'},
      {0x0253, 'b'},  {0x0254, 'o'},  {0x0255, 'c'}, {0x0256, 'd'}, {0x0257, 'd'}, {0x0258, 'e'},
      {0x025B, 'e'},  {0x025C, 'e'},  {0x025D, 'e'}, {0x025E, 'e'}, {0x025F, 'j'}, {0x0260, 'g'},
      {0x0261, 'g'},  {0x0262, 'G'},  {0x0265, 'h'}, {0x0266, 'h'}, {0x0268, 'i'}, {0x026A, 'I'},
      {0x026B, 'l'},  {0x026C, 'l'},  {0x026D, 'l'}, {0x026F, 'm'}, {0x0270, 'm'}, {0x0271, 'm'},
      {0x0272, 'n'},  {0x0273, 'n'},  {0x0274, 'N'}, {0x0275, 'o'}, {0x0279, 'r'}, {0x027A, 'r'},
      {0x027B, 'r'},  {0x027C, 'r'},  {0x027D, 'r'}, {0x027E, 'r'}, {0x027F, 'r'}, {0x0280, 'R'},
      {0x0281, 'R'},  {0x0282, 's'},  {0x0287, 't'}, {0x0288, 't'}, {0x0289, 'u'}, {0x028B, 'v'},
      {0x028C, 'v'},  {0x028D, 'w'},  {0x028E, 'y'}, {0x028F, 'Y'}, {0x0290, 'z'}, {0x0291, 'z'},
      {0x0297, 'c'},  {0x0299, 'B'},  {0x029A, 'e'}, {0x029B, 'G'}, {0x029C, 'H'}, {0x029D, 'j'},
      {0x029E, 'k'},  {0x029F, 'L'},  {0x02A0, 'q'}, {0x02AE, 'h'}, {0x0363, 'a'}, {0x0364, 'e'},
      {0x0365, 'i'},  {0x0366, 'o'},  {0x0367, 'u'}, {0x0368, 'c'}, {0x0369, 'd'}, {0x036A, 'h'},
      {0x036B, 'm'},  {0x036C, 'r'},  {0x036D, 't'}, {0x036E, 'v'}, {0x036F, 'x'}, {0x1D00, 'A'},
      {0x1D03, 'B'},  {0x1D04, 'C'},  {0x1D05, 'D'}, {0x1D07, 'E'}, {0x1D08, 'e'}, {0x1D09, 'i'},
      {0x1D0A, 'J'},  {0x1D0B, 'K'},  {0x1D0C, 'L'}, {0x1D0D, 'M'}, {0x1D0E, 'N'}, {0x1D0F, 'O'},
      {0x1D10, 'O'},  {0x1D11, 'o'},  {0x1D12, 'o'}, {0x1D13, 'o'}, {0x1D16, 'o'}, {0x1D17, 'o'},
      {0x1D18, 'P'},  {0x1D19, 'R'},  {0x1D1A, 'R'}, {0x1D1B, 'T'}, {0x1D1C, 'U'}, {0x1D1D, 'u'},
      {0x1D1E, 'u'},  {0x1D1F, 'm'},  {0x1D20, 'V'}, {0x1D21, 'W'}, {0x1D22, 'Z'}, {0x1D62, 'i'},
      {0x1D63, 'r'},  {0x1D64, 'u'},  {0x1D65, 'v'}, {0x1E00, 'A'}, {0x1E01, 'a'}, {0x1E02, 'B'},
      {0x1E03, 'b'},  {0x1E04, 'B'},  {0x1E05, 'b'}, {0x1E06, 'B'}, {0x1E07, 'b'}, {0x1E0A, 'D'},
      {0x1E0B, 'd'},  {0x1E0C, 'D'},  {0x1E0D, 'd'}, {0x1E0E, 'D'}, {0x1E0F, 'd'}, {0x1E10, 'D'},
      {0x1E11, 'd'},  {0x1E12, 'D'},  {0x1E13, 'd'}, {0x1E18, 'E'}, {0x1E19, 'e'}, {0x1E1A, 'E'},
      {0x1E1B, 'e'},  {0x1E1E, 'F'},  {0x1E1F, 'f'}, {0x1E20, 'G'}, {0x1E21, 'g'}, {0x1E22, 'H'},
      {0x1E23, 'h'},  {0x1E24, 'H'},  {0x1E25, 'h'}, {0x1E26, 'H'}, {0x1E27, 'h'}, {0x1E28, 'H'},
      {0x1E29, 'h'},  {0x1E2A, 'H'},  {0x1E2B, 'h'}, {0x1E2C, 'I'}, {0x1E2D, 'i'}, {0x1E30, 'K'},
      {0x1E31, 'k'},  {0x1E32, 'K'},  {0x1E33, 'k'}, {0x1E34, 'K'}, {0x1E35, 'k'}, {0x1E36, 'L'},
      {0x1E37, 'l'},  {0x1E3A, 'L'},  {0x1E3B, 'l'}, {0x1E3C, 'L'}, {0x1E3D, 'l'}, {0x1E3E, 'M'},
      {0x1E3F, 'm'},  {0x1E40, 'M'},  {0x1E41, 'm'}, {0x1E42, 'M'}, {0x1E43, 'm'}, {0x1E44, 'N'},
      {0x1E45, 'n'},  {0x1E46, 'N'},  {0x1E47, 'n'}, {0x1E48, 'N'}, {0x1E49, 'n'}, {0x1E4A, 'N'},
      {0x1E4B, 'n'},  {0x1E54, 'P'},  {0x1E55, 'p'}, {0x1E56, 'P'}, {0x1E57, 'p'}, {0x1E58, 'R'},
      {0x1E59, 'r'},  {0x1E5A, 'R'},  {0x1E5B, 'r'}, {0x1E5E, 'R'}, {0x1E5F, 'r'}, {0x1E60, 'S'},
      {0x1E61, 's'},  {0x1E62, 'S'},  {0x1E63, 's'}, {0x1E6A, 'T'}, {0x1E6B, 't'}, {0x1E6C, 'T'},
      {0x1E6D, 't'},  {0x1E6E, 'T'},  {0x1E6F, 't'}, {0x1E70, 'T'}, {0x1E71, 't'}, {0x1E72, 'U'},
      {0x1E73, 'u'},  {0x1E74, 'U'},  {0x1E75, 'u'}, {0x1E76, 'U'}, {0x1E77, 'u'}, {0x1E7C, 'V'},
      {0x1E7D, 'v'},  {0x1E7E, 'V'},  {0x1E7F, 'v'}, {0x1E80, 'W'}, {0x1E81, 'w'}, {0x1E82, 'W'},
      {0x1E83, 'w'},  {0x1E84, 'W'},  {0x1E85, 'w'}, {0x1E86, 'W'}, {0x1E87, 'w'}, {0x1E88, 'W'},
      {0x1E89, 'w'},  {0x1E8A, 'X'},  {0x1E8B, 'x'}, {0x1E8C, 'X'}, {0x1E8D, 'x'}, {0x1E8E, 'Y'},
      {0x1E8F, 'y'},  {0x1E90, 'Z'},  {0x1E91, 'z'}, {0x1E92, 'Z'}, {0x1E93, 'z'}, {0x1E94, 'Z'},
      {0x1E95, 'z'},  {0x1E96, 'h'},  {0x1E97, 't'}, {0x1E98, 'w'}, {0x1E99, 'y'}, {0x1E9A, 'a'},
      {0x1E9B, 's'},  {0x1EA0, 'A'},  {0x1EA1, 'a'}, {0x1EA2, 'A'}, {0x1EA3, 'a'}, {0x1EB8, 'E'},
      {0x1EB9, 'e'},  {0x1EBA, 'E'},  {0x1EBB, 'e'}, {0x1EBC, 'E'}, {0x1EBD, 'e'}, {0x1EC8, 'I'},
      {0x1EC9, 'i'},  {0x1ECA, 'I'},  {0x1ECB, 'i'}, {0x1ECC, 'O'}, {0x1ECD, 'o'}, {0x1ECE, 'O'},
      {0x1ECF, 'o'},  {0x1EE4, 'U'},  {0x1EE5, 'u'}, {0x1EE6, 'U'}, {0x1EE7, 'u'}, {0x1EF2, 'Y'},
      {0x1EF3, 'y'},  {0x1EF4, 'Y'},  {0x1EF5, 'y'}, {0x1EF6, 'Y'}, {0x1EF7, 'y'}, {0x1EF8, 'Y'},
      {0x1EF9, 'y'},  {0x2071, 'i'},  {0x2095, 'h'}, {0x2096, 'k'}, {0x2097, 'l'}, {0x2098, 'm'},
      {0x2099, 'n'},  {0x209A, 'p'},  {0x209B, 's'}, {0x209C, 't'}, {0x2183, 'C'}, {0x2184, 'c'},
      {0x2C62, 'L'},  {0x2C64, 'R'},  {0x2C65, 'a'}, {0x2C66, 't'}, {0x2C6D, 'A'}, {0x2C6E, 'M'},
      {0x2C6F, 'A'},  {0x2C7E, 'S'},  {0x2C7F, 'Z'}, {0xA78D, 'H'}, {0xA7AA, 'H'}, {0xA7AB, 'E'},
      {0xA7AC, 'G'},  {0xA7AD, 'L'},  {0xA7AE, 'I'}, {0xA7B0, 'K'}, {0xA7B1, 'T'}, {0xA7B2, 'J'},
      {0xA7C5, 'S'},  {0xFF01, '!'},  {0xFF02, '"'}, {0xFF03, '#'}, {0xFF04, '$'}, {0xFF05, '%'},
      {0xFF06, '&'},  {0xFF07, '\''}, {0xFF08, '('}, {0xFF09, ')'}, {0xFF0A, '*'}, {0xFF0B, '+'},
      {0xFF0C, ','},  {0xFF0D, '-'},  {0xFF0E, '.'}, {0xFF0F, '/'}, {0xFF10, '0'}, {0xFF11, '1'},
      {0xFF12, '2'},  {0xFF13, '3'},  {0xFF14, '4'}, {0xFF15, '5'}, {0xFF16, '6'}, {0xFF17, '7'},
      {0xFF18, '8'},  {0xFF19, '9'},  {0xFF1A, ':'}, {0xFF1B, ';'}, {0xFF1C, '<'}, {0xFF1D, '='},
      {0xFF1E, '>'},  {0xFF1F, '?'},  {0xFF20, '@'}, {0xFF21, 'A'}, {0xFF22, 'B'}, {0xFF23, 'C'},
      {0xFF24, 'D'},  {0xFF25, 'E'},  {0xFF26, 'F'}, {0xFF27, 'G'}, {0xFF28, 'H'}, {0xFF29, 'I'},
      {0xFF2A, 'J'},  {0xFF2B, 'K'},  {0xFF2C, 'L'}, {0xFF2D, 'M'}, {0xFF2E, 'N'}, {0xFF2F, 'O'},
      {0xFF30, 'P'},  {0xFF31, 'Q'},  {0xFF32, 'R'}, {0xFF33, 'S'}, {0xFF34, 'T'}, {0xFF35, 'U'},
      {0xFF36, 'V'},  {0xFF37, 'W'},  {0xFF38, 'X'}, {0xFF39, 'Y'}, {0xFF3A, 'Z'}, {0xFF3B, '['},
      {0xFF3C, '\\'}, {0xFF3D, ']'},  {0xFF3E, '^'}, {0xFF3F, '_'}, {0xFF40, '`'}, {0xFF41, 'a'},
      {0xFF42, 'b'},  {0xFF43, 'c'},  {0xFF44, 'd'}, {0xFF45, 'e'}, {0xFF46, 'f'}, {0xFF47, 'g'},
      {0xFF48, 'h'},  {0xFF49, 'i'},  {0xFF4A, 'j'}, {0xFF4B, 'k'}, {0xFF4C, 'l'}, {0xFF4D, 'm'},
      {0xFF4E, 'n'},  {0xFF4F, 'o'},  {0xFF50, 'p'}, {0xFF51, 'q'}, {0xFF52, 'r'}, {0xFF53, 's'},
      {0xFF54, 't'},  {0xFF55, 'u'},  {0xFF56, 'v'}, {0xFF57, 'w'}, {0xFF58, 'x'}, {0xFF59, 'y'},
      {0xFF5A, 'z'},  {0xFF5B, '{'},  {0xFF5C, '|'}, {0xFF5D, '}'}, {0xFF5E, '~'}, {0xFF61, '.'},
  });
  std::ranges::sort(table, {}, &FoldEntry::cp);
  return table;
}();

inline constexpr char32_t NORMALIZE_MIN = 0x00C0;
inline constexpr char32_t NORMALIZE_MAX = 0xFF61;

// folded ASCII char for a diacritic/variant codepoint, or 0 if none
inline char foldDiacritic(char32_t cp) {
  if (cp < NORMALIZE_MIN || cp > NORMALIZE_MAX) { return 0; }
  const auto it = std::lower_bound(NORMALIZE_TABLE.begin(), NORMALIZE_TABLE.end(), cp,
                                   [](const FoldEntry &e, char32_t v) { return e.cp < v; });
  if (it != NORMALIZE_TABLE.end() && it->cp == cp) { return it->base; }
  return 0;
}

// decodes one codepoint at byte i -> {codepoint, byteLength}; invalid input
// yields {raw byte, 1} so iteration always advances
inline std::pair<char32_t, int> decodeUtf8(std::string_view s, size_t i) {
  const unsigned char b0 = static_cast<unsigned char>(s[i]);
  if (b0 < 0x80) { return {b0, 1}; }

  int len = 0;
  char32_t cp = 0;
  if ((b0 & 0xE0) == 0xC0) {
    len = 2;
    cp = b0 & 0x1F;
  } else if ((b0 & 0xF0) == 0xE0) {
    len = 3;
    cp = b0 & 0x0F;
  } else if ((b0 & 0xF8) == 0xF0) {
    len = 4;
    cp = b0 & 0x07;
  } else {
    return {b0, 1};
  }

  if (i + static_cast<size_t>(len) > s.size()) { return {b0, 1}; }
  for (int k = 1; k < len; ++k) {
    const unsigned char bk = static_cast<unsigned char>(s[i + k]);
    if ((bk & 0xC0) != 0x80) { return {b0, 1}; }
    cp = (cp << 6) | (bk & 0x3F);
  }
  return {cp, len};
}

inline int encodeUtf8(char32_t cp, std::array<char, 4> &out) {
  if (cp < 0x80) {
    out[0] = static_cast<char>(cp);
    return 1;
  }
  if (cp < 0x800) {
    out[0] = static_cast<char>(0xC0 | (cp >> 6));
    out[1] = static_cast<char>(0x80 | (cp & 0x3F));
    return 2;
  }
  if (cp < 0x10000) {
    out[0] = static_cast<char>(0xE0 | (cp >> 12));
    out[1] = static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
    out[2] = static_cast<char>(0x80 | (cp & 0x3F));
    return 3;
  }
  out[0] = static_cast<char>(0xF0 | (cp >> 18));
  out[1] = static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
  out[2] = static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
  out[3] = static_cast<char>(0x80 | (cp & 0x3F));
  return 4;
}

struct TranslitEntry {
  char32_t cp;
  std::string_view ascii;
  std::string_view alt = "";
};

/**
 * Non-Latin letters spelled out in ASCII. Keyed by lowercase codepoint, except for
 * the Greek accented capitals whose lowercase partners are not a fixed offset away.
 *
 * The matcher is a subsequence matcher, so a spelling longer than the Latin one it
 * has to match rules the item out entirely, while a shorter one still matches at a
 * gap penalty: prefer under-expanding (щ -> "sh", not "shch"; х -> "h", not "kh").
 * `alt` covers sounds with two common Latin spellings, notably /k/ written "c" in
 * Calculator or Discord and "k" in Konsole or Kitty.
 */
inline constexpr auto TRANSLIT_TABLE = [] {
  auto table = std::to_array<TranslitEntry>({
      {0x0430, "a"},  {0x0431, "b"},  {0x0432, "v"}, {0x0433, "g"},      {0x0434, "d"},      {0x0435, "e"},
      {0x0436, "zh"}, {0x0437, "z"},  {0x0438, "i"}, {0x0439, "i"},      {0x043A, "k", "c"}, {0x043B, "l"},
      {0x043C, "m"},  {0x043D, "n"},  {0x043E, "o"}, {0x043F, "p"},      {0x0440, "r"},      {0x0441, "s"},
      {0x0442, "t"},  {0x0443, "u"},  {0x0444, "f"}, {0x0445, "h"},      {0x0446, "c"},      {0x0447, "ch"},
      {0x0448, "sh"}, {0x0449, "sh"}, {0x044A, ""},  {0x044B, "y"},      {0x044C, ""},       {0x044D, "e"},
      {0x044E, "u"},  {0x044F, "a"},  {0x0451, "e"}, {0x0452, "d"},      {0x0453, "g"},      {0x0454, "e"},
      {0x0455, "z"},  {0x0456, "i"},  {0x0457, "i"}, {0x0458, "i"},      {0x0459, "l"},      {0x045A, "n"},
      {0x045B, "c"},  {0x045C, "k"},  {0x045E, "u"}, {0x045F, "d"},      {0x0491, "g"},

      {0x03B1, "a"},  {0x03B2, "b"},  {0x03B3, "g"}, {0x03B4, "d"},      {0x03B5, "e"},      {0x03B6, "z"},
      {0x03B7, "i"},  {0x03B8, "th"}, {0x03B9, "i"}, {0x03BA, "k", "c"}, {0x03BB, "l"},      {0x03BC, "m"},
      {0x03BD, "n"},  {0x03BE, "x"},  {0x03BF, "o"}, {0x03C0, "p"},      {0x03C1, "r"},      {0x03C2, "s"},
      {0x03C3, "s"},  {0x03C4, "t"},  {0x03C5, "u"}, {0x03C6, "f"},      {0x03C7, "h"},      {0x03C8, "ps"},
      {0x03C9, "o"},  {0x03AC, "a"},  {0x03AD, "e"}, {0x03AE, "i"},      {0x03AF, "i"},      {0x03CA, "i"},
      {0x03CB, "u"},  {0x03CC, "o"},  {0x03CD, "u"}, {0x03CE, "o"},      {0x0390, "i"},      {0x03B0, "u"},
      {0x0386, "a"},  {0x0388, "e"},  {0x0389, "i"}, {0x038A, "i"},      {0x038C, "o"},      {0x038E, "u"},
      {0x038F, "o"},  {0x03AA, "i"},  {0x03AB, "u"},
  });
  std::ranges::sort(table, {}, &TranslitEntry::cp);
  return table;
}();

inline constexpr char32_t foldScriptCase(char32_t cp) {
  constexpr auto GREEK_SPECIAL_CASES = std::to_array<std::pair<char32_t, char32_t>>({
      {0x0386, 0x03AC},
      {0x0388, 0x03AD},
      {0x0389, 0x03AE},
      {0x038A, 0x03AF},
      {0x038C, 0x03CC},
      {0x038E, 0x03CD},
      {0x038F, 0x03CE},
      {0x03AA, 0x03CA},
      {0x03AB, 0x03CB},
  });

  if (cp >= 0x0410 && cp <= 0x042F) { return cp + 0x20; }
  if (cp >= 0x0400 && cp <= 0x040F) { return cp + 0x50; }
  if (cp >= 0x0391 && cp <= 0x03A9) { return cp + 0x20; }
  if (cp == 0x03C2) { return 0x03C3; }
  if (cp == 0x0490) { return 0x0491; }

  for (const auto &[upper, lower] : GREEK_SPECIAL_CASES) {
    if (cp == upper) { return lower; }
  }

  return cp;
}

enum class TranslitScheme : std::uint8_t { Primary, Alternate };

inline std::optional<std::string_view>
transliterateCodepoint(char32_t cp, TranslitScheme scheme = TranslitScheme::Primary) {
  const char32_t folded = foldScriptCase(cp);
  const auto it = std::lower_bound(TRANSLIT_TABLE.begin(), TRANSLIT_TABLE.end(), folded,
                                   [](const TranslitEntry &e, char32_t v) { return e.cp < v; });
  if (it == TRANSLIT_TABLE.end() || it->cp != folded) { return std::nullopt; }
  if (scheme == TranslitScheme::Alternate && !it->alt.empty()) { return it->alt; }
  return it->ascii;
}

inline bool needsTransliteration(std::string_view text) {
  size_t i = 0;
  while (i < text.size()) {
    const auto [cp, len] = decodeUtf8(text, i);
    if (transliterateCodepoint(cp)) { return true; }
    i += static_cast<size_t>(len);
  }
  return false;
}

inline bool transliterate(std::string_view text, std::string &out,
                          TranslitScheme scheme = TranslitScheme::Primary) {
  out.clear();
  out.reserve(text.size());
  bool transliterated = false;

  size_t i = 0;
  while (i < text.size()) {
    const auto [cp, len] = decodeUtf8(text, i);
    if (const auto ascii = transliterateCodepoint(cp, scheme)) {
      out.append(*ascii);
      transliterated = true;
    } else {
      out.append(text.substr(i, static_cast<size_t>(len)));
    }
    i += static_cast<size_t>(len);
  }

  if (!transliterated || out.empty()) {
    out.clear();
    return false;
  }
  return true;
}

inline std::optional<std::string> transliterate(std::string_view text,
                                                TranslitScheme scheme = TranslitScheme::Primary) {
  std::string out;
  if (!transliterate(text, out, scheme)) { return std::nullopt; }
  return out;
}

} // namespace fzf
