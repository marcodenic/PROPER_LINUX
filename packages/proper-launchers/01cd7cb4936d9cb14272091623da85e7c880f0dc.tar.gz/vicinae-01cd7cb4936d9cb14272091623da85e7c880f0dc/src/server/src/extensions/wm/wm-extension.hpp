#pragma once
#include "command-database.hpp"
#include "../../ui/image/url.hpp"
#include "theme.hpp"
#include <qcontainerfwd.h>
#include "switch-windows-command.hpp"
#include <QCoreApplication>

class WindowManagementExtension : public BuiltinCommandRepository {
  QString id() const override { return "wm"; }
  QString displayName() const override {
    return QCoreApplication::translate("WindowManagementExtension", "Window Management");
  }
  ImageURL iconUrl() const override {
    return ImageURL::builtin(BuiltinIcon::AppWindowList).setBackgroundTint(SemanticColor::Cyan);
  }

public:
  WindowManagementExtension() { registerCommand<SwitchWindowsCommand>(); }
};
