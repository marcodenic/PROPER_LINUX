#include "command-database.hpp"
#include "../../ui/image/url.hpp"
#include "theme.hpp"
#include "browse-fonts-command.hpp"
#include <QCoreApplication>

class FontExtension : public BuiltinCommandRepository {
  QString id() const override { return "font"; }
  QString displayName() const override { return QCoreApplication::translate("FontExtension", "Font"); }
  ImageURL iconUrl() const override {
    return ImageURL::builtin(BuiltinIcon::Text).setBackgroundTint(SemanticColor::Accent);
  }

public:
  FontExtension() { registerCommand<BrowseFontsCommand>(); }
};
