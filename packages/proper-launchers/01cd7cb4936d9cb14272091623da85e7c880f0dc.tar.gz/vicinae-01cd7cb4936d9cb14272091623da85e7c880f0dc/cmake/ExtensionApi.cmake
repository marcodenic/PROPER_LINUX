set(EXT_API_SRC_DIR "${CMAKE_SOURCE_DIR}/api")
set(EXT_API_OUT_DIR "${CMAKE_SOURCE_DIR}/api/dist")
set(API_DIST_DIR "${CMAKE_SOURCE_DIR}/api/dist")
set(API_PROTO_PATH "${CMAKE_SOURCE_DIR}/proto")
set(API_PROTO_OUT "${EXT_API_SRC_DIR}/src/api/proto")

message(STATUS ${API_PROTO_PATH})

file(GLOB_RECURSE API_PROTO_FILES
	"${API_PROTO_PATH}/*.proto"
)

file(GLOB_RECURSE API_TS_FILES
    "${EXT_API_SRC_DIR}/src/api/**/*"
    "${EXT_API_SRC_DIR}/src/api/*"
)

set(EXT_API_TS_FILES)

foreach(file ${API_TS_FILES})
    if(NOT file MATCHES ".*proto.*")
		list(APPEND EXT_API_TS_FILES "${file}")
    endif()
endforeach()

file(MAKE_DIRECTORY ${API_PROTO_OUT})

set(API_STAMP "${CMAKE_CURRENT_BINARY_DIR}/api.stamp")

#foreach(file ${EXT_API_TS_FILES})
#    file(RELATIVE_PATH rel_file "${EXT_API_SRC_DIR}" "${file}")
#    message(STATUS "  ${rel_file}")
#endforeach()

add_custom_command(
    OUTPUT ${API_STAMP}
    COMMAND npm install
	COMMAND ${FIGURA_CC} compile ${CMAKE_SOURCE_DIR}/figura/extension-api.fig --client typescript --output ${API_PROTO_PATH}/api.ts
    COMMAND npm run build
    COMMAND ${CMAKE_COMMAND} -E touch ${API_STAMP}
    WORKING_DIRECTORY ${EXT_API_SRC_DIR}
    DEPENDS ${EXT_API_TS_FILES}
    COMMENT "Build API"
)

add_custom_target(api DEPENDS ${API_STAMP})
